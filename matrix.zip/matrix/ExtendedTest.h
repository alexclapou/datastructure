#pragma once
#include "ExtendedTest.h"

void testAllExtended();