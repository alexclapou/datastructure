
#include <iostream>
#include "Matrix.h"
#include "ExtendedTest.h"
#include "ShortTest.h"

using namespace std;


int main() {
    testAll();
    testAllExtended();
    /*
    Matrix m(5, 5);
    for(int i = 0; i < 5; i++){
        for(int j = 0; j < 5; j++){
            int q = rand() % 5;
            while(!q)
                q = rand() % 5;
            m.modify(i,j,q);
        }
    }
    m.show();
    */
    return 0;
}
