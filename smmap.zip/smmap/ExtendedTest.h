#pragma once


void testAllExtended();
